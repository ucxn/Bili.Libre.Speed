// This is a generated file - do not edit.
//
// Generated from bilibili/account/service/v1.proto.

// @dart = 3.3

// ignore_for_file: annotate_overrides, camel_case_types, comment_references
// ignore_for_file: constant_identifier_names
// ignore_for_file: curly_braces_in_flow_control_structures
// ignore_for_file: deprecated_member_use_from_same_package, library_prefixes
// ignore_for_file: non_constant_identifier_names, prefer_relative_imports

import 'dart:core' as $core;

import 'package:protobuf/protobuf.dart' as $pb;

class RenderSchemeEnum extends $pb.ProtobufEnum {
  static const RenderSchemeEnum Default =
      RenderSchemeEnum._(0, _omitEnumNames ? '' : 'Default');
  static const RenderSchemeEnum Colorful =
      RenderSchemeEnum._(1, _omitEnumNames ? '' : 'Colorful');

  static const $core.List<RenderSchemeEnum> values = <RenderSchemeEnum>[
    Default,
    Colorful,
  ];

  static final $core.List<RenderSchemeEnum?> _byValue =
      $pb.ProtobufEnum.$_initByValueList(values, 1);
  static RenderSchemeEnum? valueOf($core.int value) =>
      value < 0 || value >= _byValue.length ? null : _byValue[value];

  const RenderSchemeEnum._(super.value, super.name);
}

const $core.bool _omitEnumNames =
    $core.bool.fromEnvironment('protobuf.omit_enum_names');
